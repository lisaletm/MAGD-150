  let mx = 0;
  let my = 0;
  let px = 0;
  let py = 0;
  let a = 20;

function setup() {

  createCanvas(500, 500);
  background(0);
  colorMode(RGB, 255, 255, 255, 1);
  frameRate(60);
}

function draw() {

  let mx = mouseX;
  let my = mouseY;
  let px = pmouseX;
  let py = pmouseY;

  let x = (mx,px);
  let y = (my,py);

  let size = dist(mx, my, px, py);

  strokeWeight(5);
  stroke(255, 36, 98, 0.25);
  fill(125,246,255,0.25);

  circle(x,y,size + a);

  strokeWeight(1);
  noFill();
  stroke(255,176,215,0.75);

  let b = sqrt(a);
  circle(x,y,size + b);

}