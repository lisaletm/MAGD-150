//Start Button Variables
var xsb = 5;
var ysb = 375;
var wsb = 50;
var hsb = 20;

//Bright Pink Circle Variables
var radius = 20;
var xbp = 30;
var ybp = 30;

//Mid Pink Circle Variables
var xmp = 470;
var ymp = 30;

//Light Pink Circle Variables
var xlp = 470;
var ylp = 320;

//White Circle Variables
var xw = 30;
var yw = 320;

function setup() {
  createCanvas(500,400);
  colorMode(RGB,255,255,255,1);
  ellipseMode(RADIUS);
}

function mouseClicked() {
//Clicking the Bright Pink Circle makes the circles bigger
var d1 = dist(mouseX,mouseY,xbp,ybp);
  if (d1<radius) {
  	radius++;
  }

//Clicking the Mid Pink Circle makes the circles smaller
var d2 = dist(mouseX,mouseY,xmp,ymp);
  if (d2<radius) {
  	radius--;
  }

//Clicking the Light Pink Circle moves all circles to the right
var d3 = dist(mouseX,mouseY,xlp,ylp);
  if (d3<radius) {
  	(xlp = xlp+1) && (xmp = xmp+1) && (xbp = xbp+1) && (xw = xw+1);
  }

//Clicking the White Circle moves all circles to the left
var d4 = dist(mouseX,mouseY,xw,yw);
  if (d4<radius) {
  	(xlp = xlp-1) && (xmp = xmp-1) && (xbp = xbp-1) && (xw = xw-1);
  }
}

function draw() {

  noStroke();

//Start Button; pressing x and rolling mouse over bottom left white rectangle makes background white
  background (148,241,255,1);
	if (keyIsPressed) {		
		if (key == 'x') {				
				if ((mouseX > xsb) && (mouseX < xsb+wsb) && (mouseY > ysb) && (mouseY < ysb+hsb)) {		
		background(255,255,255,1);
			}				
		}
	}
  fill(0,122,140);
  rect(0,370,500,30);
  fill(255,255,255,1);
  rect(xsb,ysb,wsb,hsb);

//Bright Pink Circle
  fill(255,0,111,1);
  ellipse(xbp,ybp,radius,radius);

//Mid Pink Circle
  fill(255,89,161,1);
  ellipse(xmp,ymp,radius,radius);

//Light Pink Circle
  fill(255,148,194);
  ellipse(xlp,ylp,radius,radius);

//White Circle
  fill(255,255,255,1);
  ellipse (xw,yw,radius,radius);

//"Text"
  fill(255,255,255,0.5);
  rect(10,58,40,10);
  rect(450,58,40,10);
  rect(450,348,40,10);
  rect(10,348,40,10);
}

