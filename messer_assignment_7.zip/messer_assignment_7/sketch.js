var y = [];
print(y.length);

var num = 3;
var b = [];
var n = [];

function setup() {
  createCanvas(400,400);

  for (var i = 0; i < 2; i++) {
	y[i] = random(-200,200); 
  }

  for (var a = 0; a < num; a++) {
	b[a] = 0;
	n[a] = 0;
  }
}

function draw() {
  background(0);
  noStroke();
  for (var f = 0; f < width; f += 200) {
	grave(f, 0);
	}

  for (var i = 0; i < y.length; i++) {
  	y[i] -= 1;
  	var x = i * 200;
	ghost(x-100, y[i]+300);
	}

  fill(100);
  rect(0,300,400,100);

  for (var a = num-1; a > 0; a--) {
	b[a] = b[a-1];
	n[a] = n[a-1];
  }
  b[0] = mouseX;
  n[0] = mouseY;
  for (var a = 0; a < num; a++) {
	ghost(b[a]-200, n[a]-200);
  }
}

function grave(x,y) {
  push();
  translate(x,y);
  noStroke();
  fill(160);
  rect(50,200,100,100);
  circle(100,200,100);
  pop();
}

function ghost(x,y) {
  push();
  translate(x,y);
  noStroke();
  fill(255);
  rect(160,160,80,80);
  circle(200,160,80);
  circle(170,240,20);
  circle(190,240,20);
  circle(210,240,20);
  circle(230,240,20);
  fill(0);
  circle(180,170,20);
  circle(220,170,20);
  stroke(0);
  strokeWeight(3);
  line(190,190,210,190);
  pop();
}